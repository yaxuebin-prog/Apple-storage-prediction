import torch
import torch.nn as nn
import os
from newmodels import LSTM, LSTM_KAN, CNN, CNN_KAN  # 确保你这些模型在 models.py 或同一目录中可被导入

class Config:
    input_features = ['TEMP', 'Humi', 'VOC', 'C2H4', 'O2', 'CO2']
    output_features = ['SI']
    input_dim = len(input_features)
    output_dim = len(output_features)
    hidden_dim = 128
    num_layers = 2
    dropout = 0.3
    batch_size = 32

# 模型映射表（根据文件名关键字匹配对应模型类和构造函数参数）
model_map = {
    "LSTM_KAN": (LSTM_KAN, {'input_dim': Config.input_dim, 'hidden_dim': Config.hidden_dim,
                            'num_layers': Config.num_layers, 'output_dim': Config.output_dim}),
    "LSTM": (LSTM, {'input_dim': Config.input_dim, 'hidden_dim': Config.hidden_dim,
                    'num_layers': Config.num_layers, 'output_dim': Config.output_dim}),
    "CNN_KAN": (CNN_KAN, {'input_dim': Config.input_dim, 'hidden_dim': Config.hidden_dim,
                          'num_layers': Config.num_layers, 'output_dim': Config.output_dim}),
    "CNN": (CNN, {'input_dim': Config.input_dim, 'hidden_dim': Config.hidden_dim,
                  'num_layers': Config.num_layers, 'output_dim': Config.output_dim}),
}

def convert_to_onnx(model_path, output_path):
    for key, (model_cls, model_args) in model_map.items():
        if key in model_path:
            print(f"Converting model: {model_path} using {key} architecture")
            model = model_cls(**model_args)
            model.load_state_dict(torch.load(model_path, map_location=torch.device('cpu')))
            model.eval()

            # 构造输入示例（CNN 用 [batch, input_dim]，LSTM 用 [batch, seq_len, input_dim]）
            if 'LSTM' in key:
                dummy_input = torch.randn(Config.batch_size, 10, Config.input_dim)  # seq_len=10 可自定义
            else:
                dummy_input = torch.randn(Config.batch_size, Config.input_dim)

            torch.onnx.export(
                model,
                dummy_input,
                output_path,
                input_names=['input'],
                output_names=['output'],
                dynamic_axes={'input': {0: 'batch'}, 'output': {0: 'batch'}},
                opset_version=11
            )
            print(f"Saved ONNX model to: {output_path}")
            return
    print(f"未能识别模型类型：{model_path}")

def batch_convert_pth_to_onnx(pth_folder, onnx_folder):
    os.makedirs(onnx_folder, exist_ok=True)
    for filename in os.listdir(pth_folder):
        if filename.endswith(".pth"):
            model_path = os.path.join(pth_folder, filename)
            onnx_path = os.path.join(onnx_folder, filename.replace(".pth", ".onnx"))
            convert_to_onnx(model_path, onnx_path)

# 设置路径
pth_folder = "saved_models"
onnx_folder = "onnx_models"

batch_convert_pth_to_onnx(pth_folder, onnx_folder)
