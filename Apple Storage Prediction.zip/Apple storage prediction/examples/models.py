import torch
import torch.nn as nn
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import os
import time
from sklearn.metrics import explained_variance_score  # 新增此行
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
# 在代码的导入部分添加
from sklearn.metrics import (
    explained_variance_score,
    mean_absolute_error,
    mean_squared_error,
    r2_score
)
import matplotlib.pyplot as plt
import numpy as np
from sklearn.metrics import r2_score, mean_squared_error
from fftKAN import *
from effKAN import *
import os
import torch
import torch.nn.utils.prune as prune


class LSTM_KAN(nn.Module):
    def __init__(self, input_dim, hidden_dim, num_layers=1, output_dim=1, bidirectional=False):
        super().__init__()
        self.hidden_dim = hidden_dim * 2 if bidirectional else hidden_dim
        self.num_layers = num_layers
        self.bidirectional = bidirectional

        self.lstm = nn.LSTM(
            input_size=input_dim,
            hidden_size=hidden_dim,
            num_layers=num_layers,
            batch_first=True,
            bidirectional=bidirectional,
            dropout=0.3 if num_layers > 1 else 0
        )

        self.bn = nn.Sequential(
            nn.BatchNorm1d(self.hidden_dim),
            nn.Dropout(0.2)
        )

        self.kan = KAN([self.hidden_dim, 64, output_dim])  # 替代全连接层

        self._init_weights()

    def _init_weights(self):
        for name, param in self.named_parameters():
            if 'weight' in name:
                if 'lstm' in name:
                    nn.init.xavier_normal_(param)
                elif 'bn' in name:
                    nn.init.normal_(param, mean=1.0, std=0.02)
            elif 'bias' in name:
                nn.init.constant_(param, 0.1)

    def forward(self, x):
        if x.dim() == 2:
            x = x.unsqueeze(1)
        elif x.dim() != 3:
            raise ValueError(f"输入维度错误：应为2D或3D张量，实际为{x.dim()}D")

        device = x.device
        h_dim = self.hidden_dim // (2 if self.bidirectional else 1)
        h0 = torch.zeros(self.num_layers * (2 if self.bidirectional else 1),
                         x.size(0), h_dim).to(device)
        c0 = torch.zeros_like(h0)

        lstm_out, _ = self.lstm(x, (h0, c0))
        last_step = lstm_out[:, -1, :]

        normalized = self.bn(last_step)
        return self.kan(normalized)



class LSTM(nn.Module):
    def __init__(self, input_dim, hidden_dim, num_layers=1, output_dim=1, bidirectional=False):
        super().__init__()
        self.hidden_dim = hidden_dim * 2 if bidirectional else hidden_dim
        self.num_layers = num_layers
        self.bidirectional = bidirectional

        # LSTM 核心层（[[4]](#__4) [[7]](#__7)）
        self.lstm = nn.LSTM(
            input_size=input_dim,
            hidden_size=hidden_dim,
            num_layers=num_layers,
            batch_first=True,
            bidirectional=bidirectional,
            dropout=0.3 if num_layers > 1 else 0
        )

        # 批归一化层（[[11]](#__11)）
        self.bn = nn.Sequential(
            nn.BatchNorm1d(self.hidden_dim),
            nn.Dropout(0.2)
        )

        # 全连接层（[[18]](#__18)）
        self.fc = nn.Sequential(
            nn.Linear(self.hidden_dim, 64),
            nn.SiLU(),
            nn.Linear(64, output_dim)
        )

        # 参数初始化优化（[[7]](#__7) [[11]](#__11)）
        self._init_weights()

    def _init_weights(self):
        for name, param in self.named_parameters():
            if 'weight' in name:
                if 'lstm' in name:
                    nn.init.xavier_normal_(param)  # LSTM权重初始化
                elif 'bn' in name:
                    nn.init.normal_(param, mean=1.0, std=0.02)  # Batchnorm特殊处理
                else:
                    nn.init.kaiming_normal_(param)  # 全连接层初始化
            elif 'bias' in name:
                nn.init.constant_(param, 0.1)

    def forward(self, x):
        # 自动维度处理（[[4]](#__4)）
        if x.dim() == 2:
            x = x.unsqueeze(1)  # [batch, 1, features]
        elif x.dim() != 3:
            raise ValueError(f"输入维度错误：应为2D或3D张量，实际维度为{x.dim()}D")

        # 设备感知的隐状态初始化（[[7]](#__7)）
        device = x.device
        h_dim = self.hidden_dim // (2 if self.bidirectional else 1)
        h0 = torch.zeros(self.num_layers * (2 if self.bidirectional else 1),
                         x.size(0), h_dim).to(device)
        c0 = torch.zeros_like(h0)

        # LSTM前向传播（[[11]](#__11)）
        lstm_out, _ = self.lstm(x, (h0, c0))
        last_step = lstm_out[:, -1, :]

        # 特征处理（[[18]](#__18)）
        normalized = self.bn(last_step)
        return self.fc(normalized)





class BiLSTM(nn.Module):
    def __init__(self, input_dim, hidden_dim, num_layers=1, output_dim=1):
        super().__init__()
        self.hidden_dim = hidden_dim * 2
        self.num_layers = num_layers

        self.lstm = nn.LSTM(
            input_size=input_dim,
            hidden_size=hidden_dim,
            num_layers=num_layers,
            batch_first=True,
            bidirectional=True,
            dropout=0.3 if num_layers > 1 else 0
        )

        self.bn = nn.Sequential(
            nn.BatchNorm1d(self.hidden_dim),
            nn.Dropout(0.2)
        )

        self.fc = nn.Sequential(
            nn.Linear(self.hidden_dim, 64),
            nn.SiLU(),
            nn.Linear(64, output_dim)
        )

        self._init_weights()

    def _init_weights(self):
        for name, param in self.named_parameters():
            if 'weight' in name:
                if 'lstm' in name:
                    nn.init.xavier_normal_(param)
                elif 'bn' in name:
                    nn.init.normal_(param, mean=1.0, std=0.02)
                else:
                    nn.init.kaiming_normal_(param)
            elif 'bias' in name:
                nn.init.constant_(param, 0.1)

    def forward(self, x):
        if x.dim() == 2:
            x = x.unsqueeze(1)
        elif x.dim() != 3:
            raise ValueError(f"输入维度错误：应为2D或3D张量，实际为{x.dim()}D")

        device = x.device
        h0 = torch.zeros(self.num_layers * 2, x.size(0), self.hidden_dim // 2).to(device)
        c0 = torch.zeros_like(h0)

        lstm_out, _ = self.lstm(x, (h0, c0))
        last_step = lstm_out[:, -1, :]

        normalized = self.bn(last_step)
        return self.fc(normalized)


class BiLSTM_KAN(nn.Module):
    def __init__(self, input_dim, hidden_dim, num_layers=1, output_dim=1):
        super().__init__()
        self.hidden_dim = hidden_dim * 2
        self.num_layers = num_layers

        self.lstm = nn.LSTM(
            input_size=input_dim,
            hidden_size=hidden_dim,
            num_layers=num_layers,
            batch_first=True,
            bidirectional=True,
            dropout=0.3 if num_layers > 1 else 0
        )

        self.bn = nn.Sequential(
            nn.BatchNorm1d(self.hidden_dim),
            nn.Dropout(0.2)
        )

        self.kan = KAN([self.hidden_dim, 64, output_dim])

        self._init_weights()

    def _init_weights(self):
        for name, param in self.named_parameters():
            if 'weight' in name:
                if 'lstm' in name:
                    nn.init.xavier_normal_(param)
                elif 'bn' in name:
                    nn.init.normal_(param, mean=1.0, std=0.02)
            elif 'bias' in name:
                nn.init.constant_(param, 0.1)

    def forward(self, x):
        if x.dim() == 2:
            x = x.unsqueeze(1)
        elif x.dim() != 3:
            raise ValueError(f"输入维度错误：应为2D或3D张量，实际为{x.dim()}D")

        device = x.device
        h0 = torch.zeros(self.num_layers * 2, x.size(0), self.hidden_dim // 2).to(device)
        c0 = torch.zeros_like(h0)

        lstm_out, _ = self.lstm(x, (h0, c0))
        last_step = lstm_out[:, -1, :]

        normalized = self.bn(last_step)
        return self.kan(normalized)


class Chomp1d(nn.Module):
    def __init__(self, chomp_size):
        super().__init__()
        self.chomp_size = chomp_size

    def forward(self, x):
        return x[:, :, :-self.chomp_size].contiguous()

class TemporalBlock(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, stride, dilation, padding, dropout):
        super().__init__()
        self.conv1 = nn.Conv1d(in_channels, out_channels, kernel_size,
                               stride=stride, padding=padding, dilation=dilation)
        self.chomp1 = Chomp1d(padding)
        self.relu1 = nn.ReLU()
        self.dropout1 = nn.Dropout(dropout)

        self.conv2 = nn.Conv1d(out_channels, out_channels, kernel_size,
                               stride=stride, padding=padding, dilation=dilation)
        self.chomp2 = Chomp1d(padding)
        self.relu2 = nn.ReLU()
        self.dropout2 = nn.Dropout(dropout)

        self.net = nn.Sequential(self.conv1, self.chomp1, self.relu1, self.dropout1,
                                 self.conv2, self.chomp2, self.relu2, self.dropout2)
        self.downsample = nn.Conv1d(in_channels, out_channels, 1) if in_channels != out_channels else None
        self.relu = nn.ReLU()

    def forward(self, x):
        out = self.net(x)
        res = x if self.downsample is None else self.downsample(x)
        return self.relu(out + res)

class TCN(nn.Module):
    def __init__(self, input_dim, output_dim, num_channels, kernel_size=2, dropout=0.2):
        super().__init__()
        layers = []
        num_levels = len(num_channels)
        for i in range(num_levels):
            dilation_size = 2 ** i
            in_channels = input_dim if i == 0 else num_channels[i-1]
            out_channels = num_channels[i]
            layers += [TemporalBlock(in_channels, out_channels, kernel_size, stride=1,
                                     dilation=dilation_size, padding=(kernel_size-1)*dilation_size, dropout=dropout)]
        self.network = nn.Sequential(*layers)
        self.fc = nn.Sequential(
            nn.Linear(num_channels[-1], 64),
            nn.ReLU(),
            nn.Linear(64, output_dim)
        )

    def forward(self, x):
        # x: [batch, seq_len, input_dim] → [batch, input_dim, seq_len]
        x = x.transpose(1, 2)
        out = self.network(x)
        out = out[:, :, -1]  # 最后时间步
        return self.fc(out)


class TCN_KAN(nn.Module):
    def __init__(self, input_dim, output_dim, num_channels, kernel_size=2, dropout=0.2):
        super().__init__()
        layers = []
        num_levels = len(num_channels)
        for i in range(num_levels):
            dilation_size = 2 ** i
            in_channels = input_dim if i == 0 else num_channels[i-1]
            out_channels = num_channels[i]
            layers += [TemporalBlock(in_channels, out_channels, kernel_size, stride=1,
                                     dilation=dilation_size, padding=(kernel_size-1)*dilation_size, dropout=dropout)]
        self.network = nn.Sequential(*layers)

        # 替换全连接为 KAN 层
        self.kan = KAN([num_channels[-1], 64, output_dim])

    def forward(self, x):
        x = x.transpose(1, 2)
        out = self.network(x)
        out = out[:, :, -1]  # 最后时间步
        return self.kan(out)






