import os
import torch
import torch.nn as nn
import torch.nn.utils.prune as prune
import torch.quantization
from torch.quantization import get_default_qconfig, prepare, convert

# 导入模型定义（示例路径，根据实际情况修改）
from new import LSTM, LSTM_KAN, CNN

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")



# 剪枝函数
def enhanced_pruning(model, amount=0.3):
    parameters_to_prune = []
    for module in model.modules():
        if isinstance(module, (nn.Linear, nn.Conv1d)):
            parameters_to_prune.append((module, 'weight'))
        elif isinstance(module, nn.LSTM):
            parameters_to_prune.append((module.weight_ih_l0, 'weight'))
            parameters_to_prune.append((module.weight_hh_l0, 'weight'))

    prune.global_unstructured(
        parameters_to_prune,
        pruning_method=prune.L1Unstructured,
        amount=amount
    )

    for module, _ in parameters_to_prune:
        prune.remove(module, 'weight')

    return model



# 量化函数
def advanced_quantize(model, example_input):
    model.eval().cpu()
    model.qconfig = get_default_qconfig('fbgemm')
    prepared_model = prepare(model, inplace=False)
    with torch.no_grad():
        for _ in range(10):
            prepared_model(example_input)
    quantized_model = convert(prepared_model)
    return quantized_model


def optimize_for_deployment(model, example_input):
    traced_script = torch.jit.trace(model, example_input)
    optimized_model = torch.jit.optimize_for_inference(traced_script)
    return optimized_model


def generate_example_input(model_name):
    """生成符合模型结构的示例输入"""
    if "LSTM" in model_name:
        return torch.randn(
            ModelConfig.BATCH_SIZE,
            ModelConfig.SEQ_LEN,
            ModelConfig.INPUT_DIM
        ).cpu()
    elif "CNN" in model_name:
        return torch.randn(
            ModelConfig.BATCH_SIZE,
            ModelConfig.INPUT_DIM,
            ModelConfig.SEQ_LEN
        ).cpu()
    else:
        raise ValueError(f"未知模型类型: {model_name}")


# 主流程处理
def process_single_model(model_name, model_class):
    model = model_class(ModelConfig.INPUT_DIM, ModelConfig.HIDDEN_DIM, ModelConfig.NUM_LAYERS, ModelConfig.OUTPUT_DIM)
    model.load_state_dict(torch.load(f"{model_name}.pth"))
    model.eval()

    # 剪枝
    pruned_model = enhanced_pruning(model)
    torch.save(pruned_model.state_dict(), f"{model_name}_pruned.pth")

    # 量化
    example_input = torch.randn(32, 10, 6)  # 示例输入
    quantized_model = advanced_quantize(pruned_model, example_input)
    torch.save(quantized_model.state_dict(), f"{model_name}_quantized.pth")

    # 部署优化
    optimized_model = optimize_for_deployment(quantized_model, example_input)
    torch.jit.save(optimized_model, f"{model_name}_optimized.pt")


if __name__ == "__main__":
    # 遍历处理所有模型
    for model_name, model_class in model_classes.items():
        process_single_model(model_name, model_class)

    print("\n处理完成！建议进行以下验证：")
    print("1. 使用真实数据验证模型精度")
    print("2. 在目标设备上测试推理速度")
    print("3. 检查模型文件大小变化")